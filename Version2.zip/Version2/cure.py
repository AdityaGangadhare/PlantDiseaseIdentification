import psycopg2

def get_cure(c):
    conn = psycopg2.connect(database = "CureDB", user = "postgres", password = "postgres", host = "localhost", port = "5432")
    print("Opened database successfully")
    cur = conn.cursor()
    query = "SELECT * from curedata where class = " +str(c)
    cur.execute(query)
    rows = cur.fetchall()
    for row in rows:
        print("Class = "), row[0]
        print("Disease = "), row[1]
        print("Cure = "), row[2], "\n"

    print("Operation done successfully")
    conn.close()
    return row[1],row[2]


print(get_cure(1))
